﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainController : MonoBehaviour {

	public Rotate rotatescript;

	public Spawner spawnerscript;

	public SimpleMove movescript;

	public CylinderController invisiblescript;

	public Camera backgroundcontrol;
	public Color backColor;

	// Use this for initialization
	void Start () {
		spawnerscript.SpawnObject();	
	}
	
	// Update is called once per frame
	void Update () {

		RotationControl();

		SpawnerControl();

		MoveControl();

		InvisibleControl();

		BackgroundControl();
	}

	void RotationControl() {
		//Rotate cube controller
		if (Input.GetKeyDown(KeyCode.Alpha1) && rotatescript.rotateSpeed == 0f) {
			rotatescript.rotateSpeed = 180f;
		}
		else if (Input.GetKeyDown(KeyCode.Alpha1) && rotatescript.rotateSpeed >= 1f) {
			rotatescript.rotateSpeed = 0f;
		}
	}

	void SpawnerControl() {
		//Spawn sphere controller
		if (Input.GetKeyDown(KeyCode.Alpha2)) {
			spawnerscript.SpawnObject();
		}
	}

	void MoveControl() {
		//Move capsule controller
		if (Input.GetKeyDown(KeyCode.Alpha3) && movescript.moveSpeed == 0f) {
			movescript.moveSpeed = 1f;
		}
		else if (Input.GetKeyDown(KeyCode.Alpha3) && movescript.moveSpeed >= 1f) {
			movescript.moveSpeed = 0f;
		}
	}

	void InvisibleControl() {
		if (Input.GetKeyDown(KeyCode.Alpha4)) {
			invisiblescript.rend.enabled = true;
		}
		else if (Input.GetKeyDown(KeyCode.Alpha4)) {
			invisiblescript.rend.enabled = false;
		}
	}

	bool backgroundFlag = true;
	void BackgroundControl() {
		if (Input.GetKeyDown(KeyCode.Alpha6) && backgroundFlag == false) {
			backgroundcontrol.backgroundColor = backColor;
			backgroundFlag = true;
		}
		else if (Input.GetKeyDown(KeyCode.Alpha6) && backgroundFlag == true) {
			Color randColor = new Color();
			randColor.r = Random.Range(0, 1f);
			randColor.g = Random.Range(0, 1f);
			randColor.b = Random.Range(0, 1f);
			backgroundcontrol.backgroundColor = randColor;
			backgroundFlag = false;
		}
	}
}
