﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CylinderController : MonoBehaviour {

	public Renderer rend;

	public void Update() {
		rend = GetComponent<Renderer>();
		rend.enabled = true;
	}


}
